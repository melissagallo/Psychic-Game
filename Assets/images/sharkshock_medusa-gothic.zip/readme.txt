OTF: Medusa Gothic
Dennis Ludlow 2016 all rights reserved
by Sharkshock 
dennis@sharkshock.net

Medusa Gothic is a Romanesque serif display font custom tailored for titles and logos. Subtle, yet curious leaf-like ornaments hug the ends of the lowercase C, J, and S. Alternate between all caps to ditch these leaves. Basic latin, extended latin, kerning, and extremely limited punctuation is included.
(This wasn't designed to be body text so make sure you've got the punctuation you require.) Classic Roman letterforms are combined with undulating glyphs to provide a simple, yet striking family that will command attention. This light weight typeface combined with liberal kerning will gobble up 
horizontal space and give your project a unique look. Use Medusa Gothic on your next book cover, game, billboard, or logo. 

This font like my others are free for personal use only as long as this readme file stays intact. For commercial use please contact me at dennis@sharkshock.net to discuss an end user license agreement. You can also visit www.sharkshock.net/license for more info and terms. I also design custom 
fonts for companies, logos, and many other things. If you'd like to leave me a PayPal donation you can use my email address above. Your generosity will be most appreciated! 

Thank you for your support!

visit www.sharkshock.net for more and take a bite out of BORING design!

tags: gothic, display, font, typeface, publishing, logo, title, book, cover, magazine, company, style, brand, branding, serif, dark, times, undulating, ornamental, like, poster, headline, horror, goth, title, Roman, diacritics, French, Polish, Sharkshock, German, Portuguese, European, creepy, terror, scary




